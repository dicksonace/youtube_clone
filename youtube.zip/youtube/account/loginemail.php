<?php 

include("../include/my_link.php");


 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>

	<div class="container">
		 <div class="form">
		 	
		 	<form method="post"><h2>Sign In</h2>
		 	<h3>to continue to YouTube</h3>
		 	<div class="text-field">
                <input type="text" class="input" required>
                <label>Enter your email</label>
            </div>

            
		 		<a href="#" class="forget_email">Forgot email?</a>
		 		<div style="margin-top: 30px;">
		 			<a href="create_account.php" class="create_account">Create Account</a>
		 			<input type="submit" name="next" class="next" value="Next">
		 		</div>
		 	</form>
		 </div>
	</div>

</body>
</html>