<?php 

include("../include/my_link.php");


 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>

	<div class="container">
		 <div class="form">
		 	
		 	<form method="post"><h2>Register Account</h2>
		 	<h3>to continue to YouTube </h3>
		 	<div class="text-field">
                <input type="text" class="input" required>
                <label>Enter your Firstname</label>
            </div>

            <div class="text-field">
                <input type="text" class="input" required>
                <label>Enter your surname</label>
            </div>
            <div class="text-field">
                <input type="text" class="input" required>
                <label>Enter your username</label>
            </div>
            <div class="text-field">
                <input type="text" class="input" required>
                <label>Enter your email</label>
            </div>
            
            <div class="gender">
            	<select>
            		<option value="">Select your Gender</option>
            		<option value="Male">Male</option>
            		<option value="Female">Female</option>
            		<option value="Robot">Robot</option>
            	</select>
            </div>

             <div class="country">
          	  <span>
          	  		<select id="clist" class="selectpicker countrypicker " data-flag="true" >
          	  			<option>33</option>
          	  		</select>
          	  </span>
          	  <input type="text" required>
             </div>



            <div class="text-field">
                <input type="password" class="input" required>
                <label>Enter Password</label>
            </div>
            <div class="text-field">
                <input type="password" class="input" required>
                <label>Confirm Password</label>
            </div>
  

            
		 		
		 		<div style="">
		 			<a href="#" class="create_account">Already have an account?</a>
		 			<input type="submit" name="next" class="next" value="Next" style="position: absolute;margin-left: 100px;">
		 		</div>
		 	</form>
		 </div>
	</div>

	
<script type="text/javascript">
	$(document).ready(function(){
       $('#clist').change(function(){ 
apex.item('P2_COUNTRY').setValue(document.getElementById("clist").options[document.getElementById("clist").selectedIndex].innerHTML);
})
	});
</script>

</body>
</html>