<?php 

include("../include/my_link.php");


 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>

	<div class="container">
		 <div class="form">
		 	
		 	<form method="post"><h2>Verify Account</h2>
		 	<h3>We have sent you a verification token. please verify</h3>
		 	<div class="text-field">
                <input type="text" class="input" required>
                <label>Enter Six digit code</label>
            </div>

		 		<div style="margin-top: 30px;">
		 			<input type="submit" name="next" class="next" value="verify">
		 		</div>
		 	</form>
		 </div>
	</div>

</body>
</html>