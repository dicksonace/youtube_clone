<?php 

include("../include/my_link.php");


 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>

	<div class="container">
		 <div class="form">
		 	
		 	<form method="post"><h2>Welcome</h2>
		 	<h3>dick@gmail.com</h3>
		 	<div class="text-field">
                <input type="password" class="input" required>
                <label>Enter your password</label>
                <input type="checkbox" name="" style="position: relative;left: 7px;margin: 5px;">
                <span style="position: relative;left: 10px;">Show Password</span>  
            </div>

            
		 		
		 		<div>
		 			<a href="#" class="forget_email">Forgotten password?</a>
		 			<input type="submit" name="next" class="next" value="Next" style="position: absolute;margin-left: 90px;">
		 		</div>
		 	</form>
		 </div>
	</div>

</body>
</html>