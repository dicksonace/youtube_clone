

$(document).ready(function(){

	var width = $(window).width();
	

	

   $(".toggle-sidenav-first").click(function(){
        $(this).text("");
       
   	  $(".toggle-sidenav-second").show();
   	  
   	    $(".side-nav ul li a").toggleClass("red1");
   	    $(".side-nav ul li a span").toggleClass("red2");
   	     $(".left-body").toggleClass("red3");
   	     $(".right-body").toggleClass("red4");
           $(".side-nav .home").toggleClass("red5");
   });

   $(".toggle-sidenav-second").click(function(){
   	   $(this).hide();
   	   $(".toggle-sidenav-first").html('<i class="fas fa-bars"></i>');
   	     $(".side-nav ul li a").removeClass("red1");
   	    $(".side-nav ul li a span").removeClass("red2");
   	    $(".left-body").removeClass("red3");
   	     $(".right-body").removeClass("red4");
            $(".side-nav .home").toggleClass("red5");
  });


   $(".search-toggle").click(function(){
         
         $("#search1").slideToggle();
   });

    

});