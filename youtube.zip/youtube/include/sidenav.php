<!DOCTYPE html>
<html>
<head>
	<title></title>

	
</head>
<body>

	<div class="side-nav">
		<ul>
			<li class="home"><a href="#"><i class="fas fa-home"></i><span>Home</span></a></li>
		    <li><a href="#"><i class="fas fa-fire"></i><span>Trening</span></a></li>
			<li><a href="#"><i class="fab fa-youtube"></i><span>Subscription</span></a></li>	
			<hr>
		    <li><a href="#"><i class="fas fa-atlas"></i><span>Library</span></a></li>
		    <li><a href="#"><i class="fas fa-clock"></i><span>History</span></a></li>
		    <li><a href="#"><i class="fas fa-photo-video"></i><span>Your Video</span></a></li>
		     <li><a href="#"><i class="fas fa-clock"></i><span>Watch Later</span></a></li>
		    <li><a href="#"><i class="fas fa-thumbs-up"></i><span>Liked Videos</span></a></li>


		    
		</ul>
	</div>

</body>
</html>