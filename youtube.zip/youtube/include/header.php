<?php 
session_start();

require("geolocation.php"); ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script type="text/javascript" src="./js/navbar.js"></script>
</head>
<body>

	<div class="top-nav">
		<div class="nav-toggle">
			<button class="toggle-sidenav-first"><i class="fas fa-bars"></i></button>
			<button class="toggle-sidenav-second" style="display: none;"><i class="fas fa-times"></i></button>
		</div>

		<div class="clone-label">
			<button><i class="fab fa-youtube" style="color: red;"></i><b style="font-size: 22px;color: black;">YouTube</b><span style="font-size: 12px;color: black;"><?= $countryCode; ?></span></button>
		</div>

		<div class="search">
			<form>
				<input type="text" name="search" id="search" class="search-box" placeholder="Search....">
				<button type="submit" class="search-icon"><i class="fas fa-search"></i></button>
			    <i class="fas fa-microphone mic"></i>
			</form>
		</div>
			
		<div class="right-align">
			<button class="search-toggle"><i class="fas fa-search"></i></button>
			<button class="video-plus"><i class="fas fa-plus-square"></i> <span>Create</span></button>
			<button class="notification"><i class="fas fa-bell"></i></button>
			<?php 
                
                if (isset($_SESSION['youtube_user'])) {
                	echo '<img src="img/icon.png" class="user-icon">';
                }else{
                	echo '<a href="account/loginemail.php"><button class="signin"><i class="fas fa-user"></i> Sign-In</button></a>';
                }


			 ?>
		</div>
				
	</div>

</body>
</html>