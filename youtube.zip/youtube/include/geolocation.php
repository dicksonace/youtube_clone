<?php 

$ip = $_SERVER['REMOTE_ADDR'];

$geoURL = "http://www.geoplugin.net/php.gp?=".$ip."";
$adddetails = unserialize(file_get_contents($geoURL,true));

//var_dump($adddetails);

$city = $adddetails['geoplugin_city'];
$ip_full = $adddetails['geoplugin_request'];
 $countryCode = $adddetails['geoplugin_countryCode'];









 ?>