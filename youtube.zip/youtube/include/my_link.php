<!DOCTYPE html>
<html>
<head>
	<title>SmokeTube</title>
	<link rel="icon" type="icon" href="../img/icon.png">
	<link rel="icon" type="icon" href="./img/icon.png">
	<link rel="stylesheet" type="text/css" href="./style/style.css">
	<link rel="stylesheet" type="text/css" href="./style/phone.css">
	<link rel="stylesheet" type="text/css" href="./style/tablet.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

</body>
</html>