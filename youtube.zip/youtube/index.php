
	<?php 
  
   include("include/my_link.php");
  
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>SmokeTube</title>
	</head>
<body>
  <?php  include("include/header.php"); ?>
	<div class="container">

		<div class="left-body">
			<?php 
              include("include/sidenav.php");
               ?>
               <div style="height: 10000px;"></div>
		</div>

		<div class="right-body">

		<div class="search" id="search1" style="display: none;">

			<form>
				<input type="text" name="search" id="search" class="search-box" placeholder="Search....">
			</form>
		</div>	
				
			
		</div>
	</div>



</script>


</script>
</body>
</html>